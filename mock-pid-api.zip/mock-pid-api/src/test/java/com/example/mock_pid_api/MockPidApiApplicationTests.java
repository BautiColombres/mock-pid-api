package com.example.mock_pid_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MockPidApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
